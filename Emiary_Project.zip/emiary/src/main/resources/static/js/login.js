let signup = document.getElementById("signup");
signup.onclick = function(){
    location.href = "/emiary/member/register";
}